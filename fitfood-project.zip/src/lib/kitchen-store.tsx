import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  seedProducts,
  recipes,
  type Goal,
  type Product,
  type Recipe,
} from "./fitfood-data";

const STORAGE_KEY = "fitfood-state-v1";

interface PersistedState {
  goal: Goal | null;
  onboarded: boolean;
  products: Product[];
}

interface KitchenContextValue extends PersistedState {
  setGoal: (g: Goal) => void;
  setOnboarded: (v: boolean) => void;
  addProducts: (items: Omit<Product, "id">[]) => void;
  removeProduct: (id: string) => void;
  clearProducts: () => void;
  resetAll: () => void;
  fridge: Product[];
  pantry: Product[];
  matchedRecipes: { recipe: Recipe; match: number; have: string[]; missing: string[] }[];
}

const KitchenContext = createContext<KitchenContextValue | null>(null);

const defaultState: PersistedState = {
  goal: null,
  onboarded: false,
  products: seedProducts,
};

export function KitchenProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistedState>(defaultState);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setState(JSON.parse(raw));
    } catch {
      /* ignore */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* ignore */
    }
  }, [state, hydrated]);

  const setGoal = useCallback((goal: Goal) => setState((s) => ({ ...s, goal })), []);
  const setOnboarded = useCallback((onboarded: boolean) => setState((s) => ({ ...s, onboarded })), []);

  const addProducts = useCallback((items: Omit<Product, "id">[]) => {
    setState((s) => ({
      ...s,
      products: [
        ...items.map((it, i) => ({ ...it, id: `g${Date.now()}-${i}` })),
        ...s.products,
      ],
    }));
  }, []);

  const removeProduct = useCallback(
    (id: string) => setState((s) => ({ ...s, products: s.products.filter((p) => p.id !== id) })),
    [],
  );

  const clearProducts = useCallback(() => setState((s) => ({ ...s, products: [] })), []);
  const resetAll = useCallback(() => setState(defaultState), []);

  const fridge = useMemo(() => state.products.filter((p) => p.location === "fridge"), [state.products]);
  const pantry = useMemo(() => state.products.filter((p) => p.location === "pantry"), [state.products]);

  const matchedRecipes = useMemo(() => {
    const names = new Set(state.products.map((p) => p.name.toLowerCase()));
    return recipes
      .map((recipe) => {
        const have = recipe.ingredients.filter((i) => names.has(i.toLowerCase()));
        const missing = recipe.ingredients.filter((i) => !names.has(i.toLowerCase()));
        const match = Math.round((have.length / recipe.ingredients.length) * 100);
        return { recipe, match, have, missing };
      })
      .sort((a, b) => b.match - a.match);
  }, [state.products]);

  const value: KitchenContextValue = {
    ...state,
    setGoal,
    setOnboarded,
    addProducts,
    removeProduct,
    clearProducts,
    resetAll,
    fridge,
    pantry,
    matchedRecipes,
  };

  return <KitchenContext.Provider value={value}>{children}</KitchenContext.Provider>;
}

export function useKitchen() {
  const ctx = useContext(KitchenContext);
  if (!ctx) throw new Error("useKitchen must be used within KitchenProvider");
  return ctx;
}
