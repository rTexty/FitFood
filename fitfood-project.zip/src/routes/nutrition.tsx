import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Flame, Beef, Wheat, Droplet, UtensilsCrossed } from "lucide-react";
import { useMemo } from "react";
import { BottomNav, PhoneShell, Scrollable, StatusBar, TopBar } from "@/components/fitfood/Shell";
import { goalLabels, goalTargets, type Goal } from "@/lib/fitfood-data";
import { generateMealPlan } from "@/lib/meal-plan";
import { useKitchen } from "@/lib/kitchen-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/nutrition")({
  head: () => ({
    meta: [
      { title: "Nutrition Dashboard — FitFood" },
      { name: "description", content: "Track daily calories, protein, carbs and fat against your goal." },
    ],
  }),
  component: Nutrition,
});

function Nutrition() {
  const { fridge, pantry, goal } = useKitchen();
  const activeGoal: Goal = goal ?? "maintain";
  const target = goalTargets[activeGoal];

  // "Eaten today" = the breakfast, lunch and snack from today's plan.
  const { consumed, eaten } = useMemo(() => {
    const plan = generateMealPlan(fridge, pantry);
    const eatenMeals = plan.meals.filter((m) => m.meal !== "Dinner");
    const totals = eatenMeals.reduce(
      (acc, m) => {
        acc.cal += m.recipe.calories;
        acc.p += m.recipe.protein;
        acc.c += m.recipe.carbs;
        acc.f += m.recipe.fat;
        return acc;
      },
      { cal: 0, p: 0, c: 0, f: 0 },
    );
    return { consumed: totals, eaten: eatenMeals };
  }, [fridge, pantry]);

  const calPct = Math.min(100, Math.round((consumed.cal / target.calories) * 100));

  return (
    <PhoneShell>
      <StatusBar />
      <TopBar
        title="Nutrition"
        subtitle={`${goalLabels[activeGoal].title} goal`}
        back="/dashboard"
        right={
          <Link
            to="/meal-plan"
            className="grid h-10 w-10 place-items-center rounded-full bg-secondary text-foreground"
            aria-label="Meal plan"
          >
            <UtensilsCrossed className="h-5 w-5" />
          </Link>
        }
      />
      <Scrollable className="px-5">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-3xl bg-primary p-5 text-primary-foreground shadow-float"
        >
          <p className="text-xs font-semibold uppercase tracking-wide opacity-90">Calories consumed today</p>
          <div className="mt-1 flex items-end gap-2">
            <p className="text-4xl font-extrabold leading-none">{consumed.cal}</p>
            <p className="pb-0.5 text-sm font-medium opacity-90">/ {target.calories} kcal</p>
          </div>
          <div className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-primary-foreground/25">
            <div className="h-full rounded-full bg-primary-foreground" style={{ width: `${calPct}%` }} />
          </div>
          <p className="mt-2 text-xs font-medium opacity-90">
            {Math.max(0, target.calories - consumed.cal)} kcal remaining · {calPct}% of goal
          </p>
        </motion.div>

        <div className="mt-4 space-y-3 rounded-2xl border border-border bg-card p-4">
          <MacroBar icon={Beef} label="Protein" value={consumed.p} target={target.protein} tone="primary" />
          <MacroBar icon={Wheat} label="Carbohydrates" value={consumed.c} target={target.carbs} tone="warning" />
          <MacroBar icon={Droplet} label="Fat" value={consumed.f} target={target.fat} tone="success" />
        </div>

        <div className="mt-4 pb-6">
          <p className="mb-2 text-sm font-bold">Daily nutrition summary</p>
          {eaten.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border bg-card px-5 py-8 text-center">
              <span className="text-3xl">🍽️</span>
              <p className="mt-2 text-sm font-semibold">Nothing logged yet</p>
              <p className="mt-1 text-xs text-muted-foreground">
                Generate a meal plan to start tracking today's nutrition.
              </p>
              <Link
                to="/meal-plan"
                className="mt-4 inline-flex items-center gap-2 rounded-2xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground"
              >
                <UtensilsCrossed className="h-4 w-4" />
                Build meal plan
              </Link>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {eaten.map((m) => (
                <div
                  key={m.meal}
                  className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3"
                >
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-secondary text-2xl">
                    {m.recipe.emoji}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[10px] font-bold uppercase tracking-wide text-primary">{m.meal}</p>
                    <p className="truncate text-sm font-semibold leading-tight">{m.recipe.name}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="flex items-center justify-end gap-1 text-sm font-bold">
                      <Flame className="h-3.5 w-3.5 text-warning-foreground" />
                      {m.recipe.calories}
                    </p>
                    <p className="text-[10px] text-muted-foreground">
                      P{m.recipe.protein} · C{m.recipe.carbs} · F{m.recipe.fat}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Scrollable>
      <BottomNav />
    </PhoneShell>
  );
}

function MacroBar({
  icon: Icon,
  label,
  value,
  target,
  tone,
}: {
  icon: typeof Beef;
  label: string;
  value: number;
  target: number;
  tone: "primary" | "warning" | "success";
}) {
  const pct = Math.min(100, Math.round((value / target) * 100));
  const bar = {
    primary: "bg-primary",
    warning: "bg-warning",
    success: "bg-success",
  }[tone];
  const chip = {
    primary: "text-primary",
    warning: "text-warning-foreground",
    success: "text-success",
  }[tone];
  return (
    <div>
      <div className="flex items-center justify-between text-sm">
        <span className="flex items-center gap-2 font-semibold">
          <Icon className={cn("h-4 w-4", chip)} />
          {label}
        </span>
        <span className="text-xs font-medium text-muted-foreground">
          <span className="font-bold text-foreground">{value}g</span> / {target}g
        </span>
      </div>
      <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-secondary">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ type: "spring", stiffness: 90, damping: 18 }}
          className={cn("h-full rounded-full", bar)}
        />
      </div>
    </div>
  );
}
