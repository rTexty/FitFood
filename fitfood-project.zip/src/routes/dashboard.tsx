import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ScanLine, Plus, PackageOpen, Refrigerator, AlertTriangle, Sparkles, Activity, UtensilsCrossed } from "lucide-react";
import { useState } from "react";
import { BottomNav, PhoneShell, Scrollable, StatusBar } from "@/components/fitfood/Shell";
import { ProductCard, StatCard } from "@/components/fitfood/widgets";
import { freshState, goalLabels } from "@/lib/fitfood-data";
import { useKitchen } from "@/lib/kitchen-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "My Kitchen — FitFood" },
      { name: "description", content: "Your fridge and pantry at a glance with live freshness stats." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { fridge, pantry, products, goal } = useKitchen();
  const [tab, setTab] = useState<"fridge" | "pantry">("fridge");

  const expiringCount = products.filter((p) => freshState(p.expiryDate) === "expiring").length;
  const expiredCount = products.filter((p) => freshState(p.expiryDate) === "expired").length;
  const list = tab === "fridge" ? fridge : pantry;

  return (
    <PhoneShell>
      <StatusBar />
      <Scrollable className="px-5">
        <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 pb-4 pt-2">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground">Good morning 👋</p>
            <h1 className="truncate text-xl font-extrabold">My Kitchen</h1>
          </div>
          <Link
            to="/profile"
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-primary text-base font-bold text-primary-foreground"
          >
            FF
          </Link>
        </header>

        {goal && (
          <div className="mb-4 flex items-center gap-2 rounded-2xl bg-primary-soft px-4 py-2.5 text-sm font-medium">
            <span className="text-base">{goalLabels[goal].emoji}</span>
            Goal: {goalLabels[goal].title}
          </div>
        )}

        <div className="grid grid-cols-3 gap-2.5">
          <StatCard label="Total items" value={products.length} hint="in kitchen" />
          <StatCard label="Expiring soon" value={expiringCount} hint="≤ 3 days" tone="warning" />
          <StatCard label="Expired" value={expiredCount} hint="use or toss" tone={expiredCount ? "danger" : "default"} />
        </div>

        <Link
          to="/scan"
          className="mt-4 flex items-center gap-3 rounded-2xl bg-primary p-4 text-primary-foreground shadow-float transition active:scale-[0.99]"
        >
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary-foreground/15">
            <ScanLine className="h-6 w-6" />
          </span>
          <span className="flex-1">
            <span className="block text-sm font-bold">Scan a receipt</span>
            <span className="block text-xs opacity-90">Auto-add products in seconds</span>
          </span>
          <Plus className="h-5 w-5" />
        </Link>

        {expiringCount > 0 && (
          <Link
            to="/expiring"
            className="mt-3 flex items-center gap-3 rounded-2xl border border-warning/40 bg-warning-soft p-3.5"
          >
            <AlertTriangle className="h-5 w-5 text-warning-foreground" />
            <span className="flex-1 text-sm font-semibold text-warning-foreground">
              {expiringCount} item{expiringCount > 1 ? "s" : ""} expiring soon
            </span>
            <span className="text-xs font-semibold text-warning-foreground">View →</span>
          </Link>
        )}

        <div className="mt-3 grid grid-cols-2 gap-2.5">
          <Link
            to="/nutrition"
            className="flex items-center gap-2.5 rounded-2xl border border-border bg-card p-3 transition hover:border-primary/40"
          >
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary">
              <Activity className="h-5 w-5" />
            </span>
            <span className="min-w-0">
              <span className="block text-sm font-bold leading-tight">Nutrition</span>
              <span className="block text-[11px] text-muted-foreground">Daily macros</span>
            </span>
          </Link>
          <Link
            to="/meal-plan"
            className="flex items-center gap-2.5 rounded-2xl border border-border bg-card p-3 transition hover:border-primary/40"
          >
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary">
              <UtensilsCrossed className="h-5 w-5" />
            </span>
            <span className="min-w-0">
              <span className="block text-sm font-bold leading-tight">Meal Plan</span>
              <span className="block text-[11px] text-muted-foreground">From fridge</span>
            </span>
          </Link>
        </div>



        <div className="mt-5 grid grid-cols-2 gap-2 rounded-2xl bg-secondary p-1">
          {(["fridge", "pantry"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold capitalize transition",
                tab === t ? "bg-card text-foreground shadow-soft" : "text-muted-foreground",
              )}
            >
              {t === "fridge" ? <Refrigerator className="h-4 w-4" /> : <PackageOpen className="h-4 w-4" />}
              {t} ({t === "fridge" ? fridge.length : pantry.length})
            </button>
          ))}
        </div>

        <div className="mt-3 flex flex-col gap-2.5 pb-6">
          {list.length === 0 ? (
            <EmptyState tab={tab} />
          ) : (
            <>
              {list.slice(0, 4).map((p, i) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.03, 0.3) }}
                >
                  <ProductCard product={p} />
                </motion.div>
              ))}
              {list.length > 4 && (
                <p className="pt-1 text-center text-xs font-medium text-muted-foreground">
                  +{list.length - 4} more in your {tab}
                </p>
              )}
            </>
          )}
        </div>

      </Scrollable>
      <BottomNav />
    </PhoneShell>
  );
}

function EmptyState({ tab }: { tab: "fridge" | "pantry" }) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed border-border bg-card px-6 py-10 text-center">
      <span className="grid h-16 w-16 place-items-center rounded-2xl bg-secondary text-3xl">
        {tab === "fridge" ? "🧊" : "🫙"}
      </span>
      <h3 className="mt-4 text-base font-bold">
        Your {tab} is empty
      </h3>
      <p className="mt-1.5 text-sm text-muted-foreground">
        {tab === "fridge"
          ? "No fresh products yet. Scan a receipt to fill it up automatically."
          : "No pantry staples yet. Add items or scan a grocery receipt."}
      </p>
      <Link
        to="/scan"
        className="mt-5 flex items-center gap-2 rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-soft"
      >
        <Sparkles className="h-4 w-4" />
        Add products
      </Link>
    </div>
  );
}
