import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  Sparkles,
  Clock,
  Flame,
  Check,
  Refrigerator,
  Sunrise,
  Sun,
  Moon,
  Cookie,
  Activity,
} from "lucide-react";
import { useMemo } from "react";
import { BottomNav, PhoneShell, Scrollable, StatusBar, TopBar } from "@/components/fitfood/Shell";
import { goalLabels } from "@/lib/fitfood-data";
import { generateMealPlan, type MealName } from "@/lib/meal-plan";
import { useKitchen } from "@/lib/kitchen-store";

export const Route = createFileRoute("/meal-plan")({
  head: () => ({
    meta: [
      { title: "Meal Plan — FitFood" },
      { name: "description", content: "Breakfast, lunch, dinner and snack ideas from what's in your fridge." },
    ],
  }),
  component: MealPlan,
});

const mealMeta: Record<MealName, { icon: typeof Sun; time: string }> = {
  Breakfast: { icon: Sunrise, time: "8:00 AM" },
  Lunch: { icon: Sun, time: "1:00 PM" },
  Dinner: { icon: Moon, time: "7:30 PM" },
  Snack: { icon: Cookie, time: "4:00 PM" },
};

function MealPlan() {
  const { fridge, pantry, goal } = useKitchen();
  const plan = useMemo(() => generateMealPlan(fridge, pantry), [fridge, pantry]);

  const totalCal = plan.meals.reduce((a, m) => a + m.recipe.calories, 0);

  return (
    <PhoneShell>
      <StatusBar />
      <TopBar
        title="Meal Plan"
        subtitle={goal ? `${goalLabels[goal].title} plan` : "From your fridge"}
        back="/dashboard"
        right={
          <Link
            to="/nutrition"
            className="grid h-10 w-10 place-items-center rounded-full bg-secondary text-foreground"
            aria-label="Nutrition"
          >
            <Activity className="h-5 w-5" />
          </Link>
        }
      />
      <Scrollable className="px-5">
        {plan.enough ? (
          <>
            <div className="mb-3 flex items-center gap-2 rounded-2xl bg-primary-soft px-4 py-3">
              <Sparkles className="h-5 w-5 text-primary" />
              <p className="text-sm font-medium">
                Built from {fridge.length} fridge items · {totalCal} kcal total
              </p>
            </div>

            <div className="flex flex-col gap-2.5 pb-6">
              {plan.meals.map((m, i) => {
                const Icon = mealMeta[m.meal].icon;
                return (
                  <motion.div
                    key={m.meal}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: Math.min(i * 0.06, 0.3) }}
                    className="rounded-2xl border border-border bg-card p-3.5"
                  >
                    <div className="mb-2 flex items-center gap-2">
                      <span className="grid h-6 w-6 place-items-center rounded-lg bg-primary-soft text-primary">
                        <Icon className="h-3.5 w-3.5" />
                      </span>
                      <p className="text-[11px] font-bold uppercase tracking-wide text-primary">{m.meal}</p>
                      <span className="ml-auto text-[11px] font-medium text-muted-foreground">
                        {mealMeta[m.meal].time}
                      </span>
                    </div>
                    <div className="flex items-start gap-3">
                      <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-secondary text-2xl">
                        {m.recipe.emoji}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-bold leading-snug">{m.recipe.name}</p>
                        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                          <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{m.recipe.minutes} min</span>
                          <span className="flex items-center gap-1"><Flame className="h-3 w-3" />{m.recipe.calories} kcal</span>
                        </div>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {m.fridgeHave.slice(0, 3).map((h) => (
                            <span
                              key={h}
                              className="flex items-center gap-1 rounded-full bg-success-soft px-2 py-0.5 text-[10px] font-medium text-success"
                            >
                              <Check className="h-2.5 w-2.5" />
                              {h}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </>
        ) : (
          <EmptyMealPlan fridgeCount={fridge.length} />
        )}
      </Scrollable>
      <BottomNav />
    </PhoneShell>
  );
}

function EmptyMealPlan({ fridgeCount }: { fridgeCount: number }) {
  return (
    <div className="flex flex-1 flex-col items-center px-2 pb-8 text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 140, damping: 16 }}
        className="relative mt-10 grid h-52 w-52 place-items-center"
      >
        <span className="absolute h-40 w-40 rounded-full bg-primary-soft" />
        <span className="absolute h-52 w-52 rounded-full border-2 border-dashed border-primary/25" />
        <span className="relative grid h-28 w-28 place-items-center rounded-[2rem] bg-card text-5xl shadow-card">
          🍽️
        </span>
        <span className="absolute right-5 top-6 grid h-9 w-9 place-items-center rounded-full bg-warning text-warning-foreground shadow-soft">
          <Refrigerator className="h-4 w-4" />
        </span>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="mt-8"
      >
        <h2 className="text-2xl font-extrabold">Not enough ingredients</h2>
        <p className="mx-auto mt-2.5 max-w-xs text-sm leading-relaxed text-muted-foreground">
          {fridgeCount === 0
            ? "Your fridge is empty, so we can't plan meals yet."
            : "There aren't enough fresh ingredients in your fridge to build a full plan."}{" "}
          Add a few more items and FitFood will generate breakfast, lunch, dinner and a snack.
        </p>
      </motion.div>

      <div className="mt-auto w-full space-y-3 pt-10">
        <Link
          to="/scan"
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-float transition active:scale-[0.98]"
        >
          <Sparkles className="h-5 w-5" />
          Add products
        </Link>
        <Link
          to="/dashboard"
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-secondary py-4 text-base font-semibold text-foreground"
        >
          <Refrigerator className="h-5 w-5" />
          Go to my kitchen
        </Link>
      </div>
    </div>
  );
}
