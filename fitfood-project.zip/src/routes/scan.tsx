import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ScanLine, ImageUp, QrCode, Info } from "lucide-react";
import { useState } from "react";
import { PhoneShell, StatusBar, TopBar } from "@/components/fitfood/Shell";

export const Route = createFileRoute("/scan")({
  head: () => ({
    meta: [
      { title: "Scan Receipt — FitFood" },
      { name: "description", content: "Scan a grocery receipt QR code to auto-add products to your kitchen." },
    ],
  }),
  component: Scan,
});

function Scan() {
  const navigate = useNavigate();
  const [scanning, setScanning] = useState(false);

  function run(toError = false) {
    setScanning(true);
    setTimeout(() => {
      navigate({ to: toError ? "/scan-error" : "/scan-success" });
    }, 1900);
  }

  return (
    <PhoneShell className="bg-foreground">
      <StatusBar dark />
      <TopBar title="Scan Receipt" subtitle="Point at the receipt QR code" back="/dashboard" />
      <div className="flex flex-1 flex-col items-center px-6 pb-8">
        <div className="relative mt-4 aspect-square w-full max-w-[300px]">
          <div className="absolute inset-0 grid place-items-center rounded-3xl bg-secondary/10">
            <QrCode className="h-28 w-28 text-primary-foreground/30" />
          </div>
          {/* corner frame */}
          {["left-3 top-3 border-l-4 border-t-4", "right-3 top-3 border-r-4 border-t-4", "left-3 bottom-3 border-l-4 border-b-4", "right-3 bottom-3 border-r-4 border-b-4"].map((c) => (
            <span key={c} className={`absolute h-10 w-10 rounded-md border-primary ${c}`} />
          ))}
          {scanning && (
            <motion.span
              initial={{ top: "8%" }}
              animate={{ top: "88%" }}
              transition={{ duration: 1, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
              className="absolute left-3 right-3 h-1 rounded-full bg-primary shadow-[0_0_20px_4px] shadow-primary"
            />
          )}
        </div>

        <p className="mt-6 text-center text-sm text-primary-foreground/70">
          {scanning ? "Reading receipt and matching products…" : "Align the QR code within the frame to import your groceries automatically."}
        </p>

        <div className="mt-auto w-full space-y-3 pt-8">
          <button
            onClick={() => run(false)}
            disabled={scanning}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-float transition active:scale-[0.98] disabled:opacity-60"
          >
            <ScanLine className="h-5 w-5" />
            {scanning ? "Scanning…" : "Scan QR code"}
          </button>
          <button
            onClick={() => run(false)}
            disabled={scanning}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-secondary/15 py-4 text-base font-semibold text-primary-foreground transition active:scale-[0.98] disabled:opacity-60"
          >
            <ImageUp className="h-5 w-5" />
            Upload receipt image
          </button>
          <button
            onClick={() => run(true)}
            disabled={scanning}
            className="flex w-full items-center justify-center gap-1.5 py-1 text-xs font-medium text-primary-foreground/50"
          >
            <Info className="h-3.5 w-3.5" />
            Demo: simulate unreadable receipt
          </button>
        </div>
      </div>
    </PhoneShell>
  );
}
