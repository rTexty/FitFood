import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Check, ArrowRight } from "lucide-react";
import { useState } from "react";
import { PhoneShell, StatusBar, TopBar } from "@/components/fitfood/Shell";
import { goalLabels } from "@/lib/fitfood-data";
import { useKitchen } from "@/lib/kitchen-store";
import { cn } from "@/lib/utils";
import type { Goal } from "@/lib/fitfood-data";

export const Route = createFileRoute("/goals")({
  head: () => ({
    meta: [
      { title: "Choose Your Goal — FitFood" },
      { name: "description", content: "Pick a health goal so FitFood can personalize your meal plans." },
    ],
  }),
  component: Goals,
});

const order: Goal[] = ["lose", "maintain", "gain"];

function Goals() {
  const { goal, setGoal, setOnboarded } = useKitchen();
  const [selected, setSelected] = useState<Goal | null>(goal);
  const navigate = useNavigate();

  function handleContinue() {
    if (!selected) return;
    setGoal(selected);
    setOnboarded(true);
    navigate({ to: "/dashboard" });
  }

  return (
    <PhoneShell>
      <StatusBar />
      <TopBar title="Your Goal" subtitle="Step 1 of 1" back="/" />
      <div className="flex flex-1 flex-col px-6 pb-8">
        <div className="mt-2">
          <h2 className="text-2xl font-extrabold leading-tight">What's your goal?</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            We'll tailor recipe matches and AI meal plans to fit it.
          </p>
        </div>

        <div className="mt-6 flex flex-col gap-3">
          {order.map((g, i) => {
            const info = goalLabels[g];
            const active = selected === g;
            return (
              <motion.button
                key={g}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * i }}
                onClick={() => setSelected(g)}
                className={cn(
                  "flex items-center gap-4 rounded-2xl border-2 p-4 text-left transition",
                  active
                    ? "border-primary bg-primary-soft shadow-soft"
                    : "border-border bg-card hover:border-primary/40",
                )}
              >
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-secondary text-2xl">
                  {info.emoji}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-base font-bold">{info.title}</span>
                  <span className="block text-xs text-muted-foreground">{info.desc}</span>
                </span>
                <span
                  className={cn(
                    "grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition",
                    active ? "border-primary bg-primary text-primary-foreground" : "border-border",
                  )}
                >
                  {active && <Check className="h-3.5 w-3.5" />}
                </span>
              </motion.button>
            );
          })}
        </div>

        <div className="mt-auto pt-8">
          <button
            onClick={handleContinue}
            disabled={!selected}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-float transition active:scale-[0.98] disabled:opacity-40 disabled:shadow-none"
          >
            Continue
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </PhoneShell>
  );
}
