import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Sparkles, Flame, Beef, Wheat, Droplet } from "lucide-react";
import { useMemo, useState } from "react";
import { BottomNav, PhoneShell, Scrollable, StatusBar, TopBar } from "@/components/fitfood/Shell";
import { recipes, goalLabels, type Recipe } from "@/lib/fitfood-data";
import { useKitchen } from "@/lib/kitchen-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/planner")({
  head: () => ({
    meta: [
      { title: "Meal Planner — FitFood" },
      { name: "description", content: "AI meal plans for the day, 3 days, or a full week with nutrition summaries." },
    ],
  }),
  component: Planner,
});

type Span = 1 | 3 | 7;
const DAY_NAMES = ["Today", "Tomorrow", "Wed", "Thu", "Fri", "Sat", "Sun"];
const MEALS = ["Breakfast", "Lunch", "Dinner"] as const;

function buildPlan(span: Span, ranked: Recipe[]) {
  const breakfasts = ranked.filter((r) => r.tag === "Breakfast" || r.tag === "Quick" || r.tag === "Bulking");
  const mains = ranked.filter((r) => !breakfasts.includes(r));
  const pick = (arr: Recipe[], i: number) => (arr.length ? arr[i % arr.length] : ranked[i % ranked.length]);
  return Array.from({ length: span }).map((_, d) => ({
    label: DAY_NAMES[d] ?? `Day ${d + 1}`,
    meals: [
      { meal: "Breakfast" as const, recipe: pick(breakfasts.length ? breakfasts : ranked, d) },
      { meal: "Lunch" as const, recipe: pick(mains.length ? mains : ranked, d) },
      { meal: "Dinner" as const, recipe: pick(mains.length ? mains : ranked, d + 1) },
    ],
  }));
}

function Planner() {
  const { matchedRecipes, goal } = useKitchen();
  const [span, setSpan] = useState<Span>(3);

  const ranked = useMemo(
    () => (matchedRecipes.length ? matchedRecipes.map((m) => m.recipe) : recipes),
    [matchedRecipes],
  );
  const plan = useMemo(() => buildPlan(span, ranked), [span, ranked]);

  const avg = useMemo(() => {
    const totals = plan.reduce(
      (acc, day) => {
        day.meals.forEach((m) => {
          acc.cal += m.recipe.calories;
          acc.p += m.recipe.protein;
          acc.c += m.recipe.carbs;
          acc.f += m.recipe.fat;
        });
        return acc;
      },
      { cal: 0, p: 0, c: 0, f: 0 },
    );
    const n = plan.length || 1;
    return {
      cal: Math.round(totals.cal / n),
      p: Math.round(totals.p / n),
      c: Math.round(totals.c / n),
      f: Math.round(totals.f / n),
    };
  }, [plan]);

  return (
    <PhoneShell>
      <StatusBar />
      <TopBar
        title="Meal Planner"
        subtitle={goal ? `${goalLabels[goal].title} plan` : "AI generated"}
        back="/dashboard"
      />
      <Scrollable className="px-5">
        <div className="grid grid-cols-3 gap-2 rounded-2xl bg-secondary p-1">
          {([1, 3, 7] as Span[]).map((s) => (
            <button
              key={s}
              onClick={() => setSpan(s)}
              className={cn(
                "rounded-xl py-2.5 text-sm font-semibold transition",
                span === s ? "bg-card text-foreground shadow-soft" : "text-muted-foreground",
              )}
            >
              {s === 1 ? "Daily" : s === 3 ? "3-Day" : "Weekly"}
            </button>
          ))}
        </div>

        <motion.div
          key={span}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 rounded-2xl bg-primary p-4 text-primary-foreground shadow-float"
        >
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4" />
            <p className="text-xs font-semibold uppercase tracking-wide opacity-90">Avg. daily nutrition</p>
          </div>
          <div className="mt-3 grid grid-cols-4 gap-2 text-center">
            <NutriPill icon={Flame} value={avg.cal} label="kcal" />
            <NutriPill icon={Beef} value={`${avg.p}g`} label="protein" />
            <NutriPill icon={Wheat} value={`${avg.c}g`} label="carbs" />
            <NutriPill icon={Droplet} value={`${avg.f}g`} label="fat" />
          </div>
        </motion.div>

        <div className="mt-4 flex flex-col gap-2 pb-6">
          {plan.map((day, di) => (
            <motion.div
              key={`${span}-${day.label}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(di * 0.04, 0.25) }}
              className="flex items-center gap-2.5 rounded-2xl border border-border bg-card p-2.5"
            >
              <div className="w-16 shrink-0">
                <p className="text-xs font-bold leading-tight">{day.label}</p>
                <p className="text-[9px] font-medium text-muted-foreground">
                  {day.meals.reduce((a, m) => a + m.recipe.calories, 0)} kcal
                </p>
              </div>
              <div className="grid flex-1 grid-cols-3 gap-1.5">
                {MEALS.map((mealName) => {
                  const slot = day.meals.find((m) => m.meal === mealName)!;
                  return (
                    <div key={mealName} className="flex items-center gap-1.5 rounded-xl bg-secondary px-2 py-1.5">
                      <span className="text-base leading-none">{slot.recipe.emoji}</span>
                      <span className="min-w-0">
                        <span className="block text-[8px] font-bold uppercase tracking-wide text-primary leading-none">
                          {mealName.slice(0, 3)}
                        </span>
                        <span className="mt-0.5 block text-[9px] font-medium leading-none text-muted-foreground">
                          {slot.recipe.calories}
                        </span>
                      </span>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          ))}
        </div>


      </Scrollable>
      <BottomNav />
    </PhoneShell>
  );
}

function NutriPill({ icon: Icon, value, label }: { icon: typeof Flame; value: string | number; label: string }) {
  return (
    <div className="rounded-xl bg-primary-foreground/15 py-2">
      <Icon className="mx-auto h-4 w-4" />
      <p className="mt-1 text-sm font-bold leading-none">{value}</p>
      <p className="text-[10px] opacity-90">{label}</p>
    </div>
  );
}
