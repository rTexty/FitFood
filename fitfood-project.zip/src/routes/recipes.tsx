import { createFileRoute } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Clock, Flame, ChevronDown, Check, ShoppingCart } from "lucide-react";
import { useState } from "react";
import { BottomNav, PhoneShell, Scrollable, StatusBar, TopBar } from "@/components/fitfood/Shell";
import { goalLabels, type Goal } from "@/lib/fitfood-data";
import { useKitchen } from "@/lib/kitchen-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/recipes")({
  head: () => ({
    meta: [
      { title: "AI Recipes — FitFood" },
      { name: "description", content: "AI recipe suggestions matched to the ingredients already in your kitchen." },
    ],
  }),
  component: Recipes,
});

function matchColor(m: number) {
  if (m >= 80) return "text-success bg-success-soft";
  if (m >= 50) return "text-warning-foreground bg-warning-soft";
  return "text-muted-foreground bg-secondary";
}

function Recipes() {
  const { matchedRecipes, goal } = useKitchen();
  const [filter, setFilter] = useState<Goal | "all">(goal ?? "all");
  const [open, setOpen] = useState<string | null>(null);

  const list = matchedRecipes.filter((m) => filter === "all" || m.recipe.goals.includes(filter));

  return (
    <PhoneShell>
      <StatusBar />
      <TopBar title="Recipe Discovery" subtitle="Matched to your kitchen" back="/dashboard" />
      <Scrollable className="px-5">
        <div className="mb-4 flex items-center gap-2 rounded-2xl bg-primary-soft px-4 py-3">
          <Sparkles className="h-5 w-5 text-primary" />
          <p className="text-sm font-medium">AI ranked these by what you already have.</p>
        </div>

        <div className="no-scrollbar -mx-5 mb-3 flex gap-2 overflow-x-auto px-5">
          {(["all", "lose", "maintain", "gain"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "shrink-0 rounded-full px-4 py-2 text-xs font-semibold capitalize transition",
                filter === f ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
              )}
            >
              {f === "all" ? "All goals" : goalLabels[f].title}
            </button>
          ))}
        </div>

        <div className="flex flex-col gap-3 pb-6">
          {list.slice(0, 4).map(({ recipe, match, have, missing }, i) => {

            const isOpen = open === recipe.id;
            return (
              <motion.div
                key={recipe.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.05, 0.3) }}
                className="overflow-hidden rounded-2xl border border-border bg-card"
              >
                <button onClick={() => setOpen(isOpen ? null : recipe.id)} className="flex w-full items-start gap-3 p-3.5 text-left">
                  <span className="grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-secondary text-3xl">
                    {recipe.emoji}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm font-bold leading-snug">{recipe.name}</p>
                      <span className={cn("shrink-0 rounded-full px-2 py-0.5 text-[11px] font-bold", matchColor(match))}>
                        {match}%
                      </span>
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{recipe.minutes} min</span>
                      <span className="flex items-center gap-1"><Flame className="h-3 w-3" />{recipe.calories} kcal</span>
                      <span className="rounded-full bg-secondary px-2 py-0.5 font-semibold">{recipe.tag}</span>
                    </div>
                    <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                      <div className="h-full rounded-full bg-primary" style={{ width: `${match}%` }} />
                    </div>
                  </div>
                  <ChevronDown className={cn("h-4 w-4 shrink-0 text-muted-foreground transition", isOpen && "rotate-180")} />
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="space-y-3 px-3.5 pb-4">
                        <div>
                          <p className="mb-1.5 text-xs font-semibold text-muted-foreground">Ingredients</p>
                          <div className="flex flex-wrap gap-1.5">
                            {have.map((h) => (
                              <span key={h} className="flex items-center gap-1 rounded-full bg-success-soft px-2.5 py-1 text-[11px] font-medium text-success">
                                <Check className="h-3 w-3" />{h}
                              </span>
                            ))}
                            {missing.map((m) => (
                              <span key={m} className="flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
                                <ShoppingCart className="h-3 w-3" />{m}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="mb-1.5 text-xs font-semibold text-muted-foreground">Steps</p>
                          <ol className="space-y-1.5">
                            {recipe.steps.map((s, idx) => (
                              <li key={idx} className="flex gap-2 text-xs">
                                <span className="grid h-4 w-4 shrink-0 place-items-center rounded-full bg-primary text-[9px] font-bold text-primary-foreground">{idx + 1}</span>
                                {s}
                              </li>
                            ))}
                          </ol>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </Scrollable>
      <BottomNav />
    </PhoneShell>
  );
}
