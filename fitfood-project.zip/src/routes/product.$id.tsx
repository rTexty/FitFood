import { createFileRoute, Link, useNavigate, useParams } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Trash2, ChefHat, CalendarClock, Package, MapPin, ScanLine, Pencil } from "lucide-react";
import { PhoneShell, StatusBar, TopBar } from "@/components/fitfood/Shell";
import { ExpiryBadge } from "@/components/fitfood/widgets";
import { daysUntil, freshState } from "@/lib/fitfood-data";
import { useKitchen } from "@/lib/kitchen-store";

export const Route = createFileRoute("/product/$id")({
  head: () => ({
    meta: [
      { title: "Product Details — FitFood" },
      { name: "description", content: "View product quantity, storage location, and estimated expiry date." },
    ],
  }),
  component: ProductDetails,
});

const storageTips: Record<string, string> = {
  Dairy: "Keep refrigerated at 1–4°C. Reseal tightly after opening.",
  Vegetables: "Store in the crisper drawer. Keep dry to slow spoilage.",
  Fruit: "Ripen at room temperature, then refrigerate to extend freshness.",
  Meat: "Keep on the coldest shelf. Freeze if not used within 2 days.",
  Fish: "Use within 1–2 days. Store on ice for best freshness.",
  Grains: "Keep in an airtight container in a cool, dry pantry.",
  Oils: "Store away from heat and light to prevent rancidity.",
  Canned: "Cool, dry place. Refrigerate after opening.",
  Snacks: "Reseal to keep crisp and prevent moisture.",
};

function ProductDetails() {
  const { id } = useParams({ from: "/product/$id" });
  const { products, removeProduct } = useKitchen();
  const navigate = useNavigate();
  const product = products.find((p) => p.id === id);

  if (!product) {
    return (
      <PhoneShell>
        <StatusBar />
        <TopBar title="Product" back="/dashboard" />
        <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
          <span className="text-4xl">🔍</span>
          <p className="mt-3 text-sm text-muted-foreground">This product is no longer in your kitchen.</p>
          <Link to="/dashboard" className="mt-5 rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground">
            Back to kitchen
          </Link>
        </div>
      </PhoneShell>
    );
  }

  const d = daysUntil(product.expiryDate);
  const state = freshState(product.expiryDate);

  function handleRemove() {
    removeProduct(product!.id);
    navigate({ to: "/dashboard" });
  }

  return (
    <PhoneShell>
      <StatusBar />
      <TopBar
        title="Product Details"
        back="/dashboard"
        right={
          <button className="grid h-10 w-10 place-items-center rounded-full bg-secondary" aria-label="Edit">
            <Pencil className="h-4 w-4" />
          </button>
        }
      />
      <div className="flex flex-1 flex-col px-6 pb-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center pt-2 text-center"
        >
          <span className="grid h-28 w-28 place-items-center rounded-3xl bg-primary-soft text-6xl">
            {product.emoji}
          </span>
          <h1 className="mt-4 text-2xl font-extrabold">{product.name}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{product.category}</p>
          <div className="mt-3">
            <ExpiryBadge expiryDate={product.expiryDate} />
          </div>
        </motion.div>

        <div className="mt-6 grid grid-cols-2 gap-3">
          <DetailTile icon={Package} label="Quantity" value={`${product.quantity}${product.unit === "count" ? " pcs" : product.unit === "pack" ? " pack" : ` ${product.unit}`}`} />
          <DetailTile icon={MapPin} label="Location" value={product.location === "fridge" ? "Fridge" : "Pantry"} />
          <DetailTile
            icon={CalendarClock}
            label="Expires"
            value={state === "expired" ? `${Math.abs(d)}d ago` : d === 0 ? "Today" : `In ${d} days`}
          />
          <DetailTile icon={product.source === "receipt" ? ScanLine : Pencil} label="Added via" value={product.source === "receipt" ? "Receipt scan" : "Manual"} />
        </div>

        <div className="mt-4 rounded-2xl border border-border bg-card p-4">
          <p className="text-xs font-semibold text-muted-foreground">Estimated expiry</p>
          <p className="mt-1 text-sm">
            AI estimated the best-before date from the product category and typical shelf life.
          </p>
          <p className="mt-3 text-xs font-semibold text-muted-foreground">Storage tip</p>
          <p className="mt-1 text-sm">{storageTips[product.category] ?? "Store appropriately to maximize freshness."}</p>
        </div>

        <div className="mt-auto space-y-3 pt-6">
          <Link
            to="/recipes"
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-float"
          >
            <ChefHat className="h-5 w-5" />
            Use in a recipe
          </Link>
          <button
            onClick={handleRemove}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-destructive-soft py-4 text-base font-semibold text-destructive"
          >
            <Trash2 className="h-5 w-5" />
            Remove from kitchen
          </button>
        </div>
      </div>
    </PhoneShell>
  );
}

function DetailTile({ icon: Icon, label, value }: { icon: typeof Package; label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-3.5">
      <Icon className="h-5 w-5 text-primary" />
      <p className="mt-2 text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-bold">{value}</p>
    </div>
  );
}
