import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Check, ArrowRight, Plus } from "lucide-react";
import { useEffect, useRef } from "react";
import { PhoneShell, StatusBar } from "@/components/fitfood/Shell";
import { ExpiryBadge } from "@/components/fitfood/widgets";
import { receiptProducts } from "@/lib/fitfood-data";
import { useKitchen } from "@/lib/kitchen-store";

export const Route = createFileRoute("/scan-success")({
  head: () => ({
    meta: [
      { title: "Receipt Added — FitFood" },
      { name: "description", content: "Your receipt was processed and products were added to your kitchen." },
    ],
  }),
  component: ScanSuccess,
});

function ScanSuccess() {
  const { addProducts } = useKitchen();
  const added = useRef(false);

  useEffect(() => {
    if (added.current) return;
    added.current = true;
    addProducts(receiptProducts);
  }, [addProducts]);

  return (
    <PhoneShell>
      <StatusBar />
      <div className="flex flex-1 flex-col px-6 pb-8">
        <div className="flex flex-col items-center pt-12 text-center">
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 14 }}
            className="grid h-24 w-24 place-items-center rounded-full bg-success text-success-foreground shadow-float"
          >
            <Check className="h-12 w-12" strokeWidth={3} />
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="mt-6 text-2xl font-extrabold"
          >
            Receipt processed!
          </motion.h1>
          <p className="mt-2 text-sm text-muted-foreground">
            We detected <span className="font-semibold text-foreground">{receiptProducts.length} products</span> and
            estimated their expiry dates automatically.
          </p>
        </div>

        <div className="mt-7 space-y-2.5">
          {receiptProducts.map((p, i) => (
            <motion.div
              key={p.name}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + i * 0.08 }}
              className="flex items-center gap-3 rounded-2xl border border-success/30 bg-success-soft p-3"
            >
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-card text-2xl">
                {p.emoji}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{p.name}</p>
                <p className="truncate text-xs text-muted-foreground capitalize">
                  {p.quantity}
                  {p.unit === "count" ? "" : p.unit === "pack" ? " pack" : ` ${p.unit}`} · {p.location}
                </p>
              </div>
              <ExpiryBadge expiryDate={p.expiryDate} />
            </motion.div>
          ))}
        </div>

        <div className="mt-auto space-y-3 pt-8">
          <Link
            to="/dashboard"
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-semibold text-primary-foreground shadow-float transition active:scale-[0.98]"
          >
            View my kitchen
            <ArrowRight className="h-5 w-5" />
          </Link>
          <Link
            to="/scan"
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-secondary py-4 text-base font-semibold text-foreground"
          >
            <Plus className="h-5 w-5" />
            Scan another receipt
          </Link>
        </div>
      </div>
    </PhoneShell>
  );
}
